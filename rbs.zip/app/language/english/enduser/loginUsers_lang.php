<?php
$lang['user_name_validation']	            	= 'User Name';
$lang['password_validation']					= 'Password';
$lang['Login to Cogzidel Lance']='Login to RBS';
$lang['Login to Private Project']='Login to Private project';
$lang['Login']='Login';
$lang['Buyer']='Buyer';
$lang['Provider']='Provider';
$lang['I forgot my login details']='I forgot my login details';
$lang['Signup']='Signup';
$lang['Login']='Login';
$lang['note']='Authorized users must login to access this private project...';
$lang['Private Project']='Private Project :';

?>