<?php
$lang['contacting']	            				= 'Contacting';
$lang['description_validation']	           		= 'Project Description';
$lang['categories_validation']					= 'Job Type';
$lang['budget_min_validation']	           		= 'Min Rate';
$lang['budget_max_validation']					= 'Max Rate';
$lang['private_list']					= 'The Provider';
$lang['contact_email_id']	       				= 'Email id';
$lang['contact_subject']	       				= 'subject';
$lang['contact_comments']	       				= 'comments';
$lang['your_email']	            				= 'Your Email';
$lang['subject']	     		  				= 'Subject';
$lang['comments']			       				= 'Comments';
$lang['submit_button']							= 'Submit Message';
$lamg['success_message']						= 'Your details sent successfully';
$lang['If you have a question,']='If you have a question,';
$lang['check the FAQ']='check the FAQ';
$lang['con']='for an answer before you contact us. You can try the RBS forum too, but note that our staff will NOT respond to you on the forum, only other members. Use the form below to contact RBS staff for important questions and problems.';
$lang['Projects Feed']='Projects Feed';
$lang['Submit Message to']='Submit Message to';
$lang['support Stafff...']='support Stafff...';
$lang['Members: Login to Support Desk...']='Members: Login to Support Desk...';
$lang['Guest Sales Questions']='Guest Sales Questions';
$lang['Submit']='Submit';
$lang['note']='Note: This contact form is for guest sales inquiries only. If you already have an account, please';
$lang['login here']='login here';

?>