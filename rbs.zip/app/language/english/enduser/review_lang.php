<?php
$lang['project_name']	            = 'Project';
$lang['review_added']	            = 'Review added successfully';
$lang['Reviews of Programmer']	    = 'Reviews of Provider';
$lang['Reviews of Buyer']	    = 'Reviews of Buyer';
$lang['Open']	            		= 'Open';
$lang['Frozen']	            		= 'Frozen';
$lang['Closed']	            		= 'Closed';

$lang['Project Name']	            = 'Project Name';
$lang['Review Date']	    = 'Review Date';
$lang['Project status']	            		= 'Project status';
$lang['Bid']	            		= 'Bid';
$lang['Buyer']	            		= 'Buyer';
$lang['Top Buyers']	            		= 'Top Buyers';
$lang['You must be logged in as a Programmer to review Buyer']	            		= 'You must be logged in as a Provider to review Buyer';
$lang['You must be logged in as a buyer to review programmer']	            		= 'You must be logged in as a buyer to review programmer';
$lang['Rating'] ='Rating';
$lang['Project Name']='Project Name';
$lang['Review Date']='Review Date';
$lang['Project status']='Project status';
$lang['Provider']='Provider';
$lang['-']='-';
$lang['Feedback for Provider']='Feedback for Provider';
$lang['Project Date']='Project Date';
$lang['How would you rate the Provider']='How would you rate the Provider';
$lang['for the project']='for the project';
$lang['Rating:']='Rating:';
$lang['Comment:']='Comment:';
$lang['Submit']='Submit';
$lang['Feedback for Buyer']='Feedback for Buyer';
$lang['How would you rate the buyer']='How would you rate the buyer';


?>