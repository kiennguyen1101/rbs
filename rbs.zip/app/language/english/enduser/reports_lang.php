<?php
$lang['Reports']	            = 'Reports';
$lang['username']	            = 'username';
$lang['Projects added last 6 months']	            = 'Projects added last 6 months';
$lang['Users Joined last 6 months']	            = 'Users Joined last 6 months';
?>
