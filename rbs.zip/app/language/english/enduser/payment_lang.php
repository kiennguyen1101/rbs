<?php
$lang['Error in payment notification']	 = 'Error in payment notification';
