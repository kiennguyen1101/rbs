<?php
$lang['error_message']	           				= 'Error Viewing on this page';
?>


