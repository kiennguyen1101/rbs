<?php
$lang['project denied']	            = 'project denied';
$lang['You have successfully denied the project']	            = 'You have successfully denied the project';
$lang['You cannot deny this project']	            = 'You cannot deny this project';
?>