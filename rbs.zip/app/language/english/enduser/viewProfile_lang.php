<?php
$lang['Buyer Profile'] = 'Buyer Profile';
$lang['Programmer Profile'] = 'Provider Profile';
$lang['Username'] = 'Username';
$lang['Provider Profile'] = 'Provider Profile';
$lang['user_not_available'] = 'User is not available';
$lang['Username:']='Username:';
$lang['Name/Company:'] ='Name/Company:';
$lang['Location:'] ='Location:';
$lang['Ratings:'] ='Ratings:';
$lang['Communication Method:']='Communication Method:';
$lang['Member Since:']='Member Since:';
$lang['Open Projects:']='Open Projects:';
$lang['Closed Projects:']='Closed Projects:';
$lang['Cancelled Projects:']='Cancelled Projects:';
$lang['reviews']='reviews';
$lang['(']= '(';
$lang['Profile']='Profile';
$lang['Country:']='Country:';
$lang['Area of Expertise:']='Area of Expertise:';
$lang['Average Pricing:']='Average Pricing:';
$lang['Last Activity:']='Last Activity:';
$lang['Profile:']='Profile:';
$lang['Portfolio:']='Portfolio:';
$lang['Title:']='Title:';
$lang['Description:']='Description:';
$lang['Category:']='Category:';
$lang['/hour']='/hour';
$lang['Contact Programmer']='Contact Provider';
$lang['Invite Programmer']='Invite Provider';
$lang['Portfolio:']='Portfolio:';
$lang['Attachement1:']='Attachement1:';
$lang['Attachement2:']='Attachement2:';

?>
