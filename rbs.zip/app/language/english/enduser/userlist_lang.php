<?php 
$lang['favorite user']					    = "Favorite User's List";
$lang['user id']					        = 'User Id';
$lang['user list']					        = 'User List';
$lang['User Id']					        = 'User Id';
$lang['User Name']					        = 'User Name';
$lang['move block']					        = 'Move to Blocked List';
$lang['move favourite']					    = 'Move to Favourite List';
$lang['Delete']					            = 'Delete';
$lang['Blocked user']					    = "Blocked User's List";
$lang['Blacklist a Buyer']					= "Blacklist a Buyer :";
$lang['Blacklist a Programmer']				= "Blacklist a Provider :";
$lang['Add Buyer to favorites']				= "Add Buyer to favorites :";
$lang['Add Programmer to favorites']		= "Add Provider to favorites :";
$lang['Enter the User name to add favourite'] = 'Enter the User name to add Favourite List';
$lang['Enter the User name to add Blocked List'] = 'Enter the User name to add Blocked List';
$lang['username']                           = 'User Name';
$lang['User does not Exists']               = 'User does not Exists';
$lang['Your input data is updated']         = 'Your input data is updated';
$lang['User already exists']                = 'User already exists';
$lang['Enter programmer name only']         = 'Enter Provider name only';
$lang['Enter buyer name only']              = 'Enter buyer name only';
$lang['Invite Programmer']                  = 'Invite Provider';
$lang['From']                               = 'From';
$lang['To']                                 = 'To';
$lang['Private User']                       = 'Private User';
$lang['Other User']                         = 'Other User';
$lang['Project Name']                       = 'Project Name';
$lang['Date']                               = 'Date';
$lang['Choose Project']                     = 'Choose Project';
$lang['favourite themself']                 = 'Unfortunately !  you could not favourite yourself';
$lang['blocked themself']                   = 'Unfortunately !  you could not blocked yourself';
$lang['If your favourite user is not in the dropdown list please enter into the Textbox']                       = 'If your favourite user is not in the dropdown list please enter into the Textbox';
$lang['User List']='User List';
$lang['Add User']='Add User';
$lang['Ban User']='Ban User';

?>