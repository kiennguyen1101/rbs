<?php
$lang['rss_feeds']	    			= 'Rss Feeds';
$lang['We_have several RSS feeds available to keep you up to date on the newest projects posted on']	= 'We have several RSS feeds available to keep you up to date on the newest projects posted on';
$lang['Click any links below to see an RSS feed, or use the form below to create your custom feed']	    = 'Click any links below to see an RSS feed, or use the form below to create your custom feed';
$lang['Projects Feed']	    		= 'Projects Feed';
$lang['Feed Content']	    		= 'Feed Content';
$lang['Titles']	   					= 'Titles';
$lang['Titles + Description']    	= 'Titles + Description';
$lang['All Projects']    			= 'All Projects';
$lang['Projects']    				= 'Projects';
$lang['The newest projects posted on']  = 'The newest projects posted on';
$lang['Copyright']  				= 'Copyright';
$lang['Custom RSS Feed']='Custom RSS Feed';
$lang['Create']='Create your own custom RSS feed by selecting the options you want.';
$lang['No of projects to display:']='No of projects to display:';
$lang['Info to display:']='Info to display:';
$lang['Categories']='Categories';
$lang['Only']='Only';
$lang['Featured']='Featured';
$lang['Urgent']='Urgent';
$lang['projects.']='projects.';
$lang['Keywords to match:']='Keywords to match:';
$lang['search']='Searches titles and full descriptions. Seperate each keyword with a comma. Example: google, message board, animated';
$lang['Create RSS Feed']='Create RSS Feed';
$lang['en-us']='en-us';
$lang['Sat, 17 Jan 2009 05:30:39 GMT']='Sat, 17 Jan 2009 05:30:39 GMT';
$lang['(c) 2009']='(c) 2009';

