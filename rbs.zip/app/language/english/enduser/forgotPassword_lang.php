<?php
$lang['user_name_validation']	            	= 'User Name';
$lang['email_validation']						= 'Mail Id';
$lang['Forgot Login Details?']='Forgot Login Details?';
$lang['Forgot your username?']='Forgot your username?';
$lang['Enter your e-mail address:']='Enter your e-mail address:';
$lang['Forgot your password?']='Forgot your password?';
$lang['Enter your username:']='Enter your username:';
$lang['Find Username']='Find Username';
$lang['E-mail Me My Password']='E-mail Me My Password';
