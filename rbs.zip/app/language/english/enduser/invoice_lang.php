<?php
$lang['Project Message Board']	            	= 'Project Message Board';

$lang['Project']								= 'Project Name';
$lang['To']							            = 'To';
$lang['You can select multiple projects by holding down the CTRL key']					= 'You can select multiple projects by holding down the CTRL key.';
$lang['Your name and address']					= 'Your name and address.';
$lang['Message for Everyone']					= 'Public Message';
$lang['Invoice Report']					        = 'Invoice Report';
$lang['Invoice No']					            = 'Invoice No';
$lang['Optional']					            = '[Optional]';
$lang['Company']					            = 'Company';
$lang['Cogzidel']					            = 'Cogzidel Technologies';
$lang['Address']					            = 'Address';
$lang['date']					                = 'Date - ';
$lang['Company Address']					    = 'Madurai';
$lang['No']					                    = 'No';
$lang['description']					        = 'Description';
$lang['amount']					                = 'Amount';
$lang['Total']					                = 'Total';
$lang['You do not have any projects posted yet']  = 'You do not have any projects posted yet.';
$lang['There is no payment is closed to view Invoice']  = 'There is no payment is closed to view Invoice.';

?>
