<?php
$lang['Pick Provider'] = "Pick Provider";
$lang['Please send the Escrow Amount'] = "Please send the Escrow Amount.";
$lang['You have successfully awarded the project'] = "You have successfully awarded the project";
$lang['Pick Bid'] = "Pick Bid";
$lang['hours']	            		= 'hours';
$lang['days']	            		= 'days';
$lang['Pick']='Pick';
$lang['Programmers']='Providers ';
$lang['Bid']='Bid';
$lang['Delivery Time']='Delivery Time';
$lang['Time of Bid']='Time of Bid';
$lang['Please add escrow to award the project']='Please Add Escrow to Award the Project';

$lang['Please select the Provider']='Please select the Provider';
?>