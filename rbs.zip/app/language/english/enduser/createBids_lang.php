<?php
$lang['You must be logged in as a Programmer to bid projects']					= 'You must be logged in as a Provider to bid projects';
$lang['Bid_Amount_validation'] 													= 'Bid Amount';
$lang['Bid_days_validation'] 													= 'Days';
$lang['You must be logged in as a programmer to place a bid']	            	= 'You must be logged in as a Provider to place a bid';
$lang['Bid on Project']	            											= 'Bid on Project';
$lang['Your Bid']	            												= 'Your Bid';
$lang['Delivery Time']	            											= 'Delivery Time';
$lang['Bid Details']	            											= 'Bid Details';
$lang['Portfolio']	            												= 'Portfolio';
$lang['Days']	            													= 'Days';
$lang['Hours']	            													= 'Hours';
$lang['Characters Left']	            										= 'Characters Left';
$lang['Submit']	            													= 'Submit';
$lang['Preview']	            												= 'Preview';
$lang['Your bid Has Been edited Successfully']	            					= 'Your bid Has Been edited Successfully';
$lang['Your bid Has Been Posted Successfully']	            					= 'Your bid has been recorded successfully. If you decide to place a new bid on this project it will replace your old bid. You will be notified by e-mail when this project closes.';
$lang['Your are not having sufficient Balance']	            					= 'Your are not having sufficient Balance';
$lang['Project Fee for Bid']	            					                = 'Project Fee for Bid';
$lang['Project Fee']	            					                        = 'Project Fee';
$lang['Programmer']	            					                            = 'Providers';
$lang['Buyer']	            					                                = 'buyer';
$lang['Project Fee for Featured Project']	            					    = 'Featured';
$lang['Project Fee for Urgent Project']	            					        = 'Urgent';
$lang['Project Fee for hide bids Project']	            					    = 'Hide Bids';
$lang['Project Fee for Private Project']	            					    = 'Private';
$lang['Job Fee']	            					                            = 'Job Fee';
$lang['Project Fee']	            					                        = ' Project Fee';



?>