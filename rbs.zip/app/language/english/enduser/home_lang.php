<?php
$lang['Featured Projects']	 = 'Featured Projects';
$lang['Urgent Projects']	 = 'Urgent Projects';
$lang['Latest 10 Projects']	 = 'Latest 10 Projects';
$lang['Post Project']		 = 'Post Project';
$lang['View All']			 = 'View All';
$lang['TOP BUYERS']			 = 'TOP BUYERS';
$lang['Services & Features']='Services & Features';

$lang['Bids']			 = 'Bids';
$lang['Avg Bid']			 = 'Avg Bid';
$lang['Job Type']			 = 'Job Type';
$lang['Posted']			 = 'Posted';
?>
