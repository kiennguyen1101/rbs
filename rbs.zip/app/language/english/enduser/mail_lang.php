<?php
$lang['Project Message Board']	            	= 'Project Message Board';
$lang['From']	            	                = 'From';
$lang['To']	            	                    = 'To';
$lang['Project']	            	            = 'Project';
$lang['Description']	            	        = 'Description';
$lang['Message']	            	            = 'Message';
$lang['Date']	            	                = 'Date';
$lang['Project Name']	            	        = 'Project Name';
$lang['There is no open project to Post Mail']	= 'There is no open project to Post Mail';

