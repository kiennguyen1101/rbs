<?php
$lang['Your input data is updated']	            	= 'Your input data is updated';
$lang['Project already Bookmarked']	            	= 'Project already Bookmarked or Exists';

?>
