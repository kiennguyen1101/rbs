<?php 
$lang['Project Message Board']	            	= 'Project Message Board';
$lang['Project']								= 'Project';
$lang['Post Message']							= 'Post Message';
$lang['private message for']					= 'private message for';
$lang['No Messages Posted']					    = 'No Messages Posted';
$lang['Message for Everyone']					= 'Public Message';
//Mail details
$lang['user']					                = 'User';
$lang['user_inbox']					            = "Inbox Messages";
$lang['Project Mail Board']	            	    = 'Project Mail Board';
$lang['View Project Mail Board']	            = 'View Project Mail Board';
$lang['Compose Project Mail Board']	            = 'Compose Project Mail';
$lang['Inbox is Empty']	                        = 'Your Inbox content is Empty';
$lang['user_outbox']					        = "Outbox Messages";
$lang['Outbox is Empty']	                    = 'Your Outbox content is Empty';

$lang['Project Id']					            = "Project Id";
$lang['Project Post Id']					    = "Project Post To";
$lang['Message']					            = "Message";
$lang['Time']					                = "Time";
$lang['Name']					                = "Name";
$lang['Project Title']					        = "Project Title";
$lang['The Keyword field is required']			= "The Keyword field is required";
$lang['Project Message Board']	            	= 'Project Message Board';
$lang['From']	            	                = 'From';
$lang['To']	            	                    = 'To';
$lang['Project']	            	            = 'Project';
$lang['Description']	            	        = 'Description';
$lang['Message']	            	            = 'Message';
$lang['Messages']	            	            = 'Messages';
$lang['Date']	            	                = 'Date';
$lang['Author']	            	                = 'Author';
$lang['Project Name']	            	        = 'Project Name';
$lang['Preview Message']	            	    = 'Preview Message';
$lang['Please choose programmer to post message']	            	    = 'Please choose Provider to post message';
$lang['You cannot post Message for this project'] 	= 'You cannot post Message for this project';
$lang['You cannot save this project as Draft'] 	    = 'You cannot save this project as Draft';
$lang['Tip: You can post programming code by placing it within [code] and [/code] tags.']	            	        = 'Tip: You can post programming code by placing it within [code] and [/code] tags.';
$lang['User ID:']='User ID:';
$lang['Go']='Go';
$lang['Message Posted:']='Message Posted:';
$lang['You are currently logged in as']='You are currently logged in as';
$lang['Preview Message']='Preview Message';
$lang['Tip']='Tip: You can post programming code by placing it within [code] and [/code] tags.';
$lang['Submit']='Submit';
$lang['Preview']='Preview';
$lang['Options']='Options';
$lang['Reply']='Reply';
$lang['You must be logged in as a buyer to post projects']='You must be logged in as a buyer to post projects';

?>