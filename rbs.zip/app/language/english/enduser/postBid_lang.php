<?php
$lang['You must be logged in as a programmer to place a bid']	            	= 'You must be logged in as a Provider to place a bid';
$lang['Bid on Project']	            											= 'Bid on Project';
$lang['Your Bid']	            												= 'Your Bid';
$lang['Delivery Time']	            											= 'Delivery Time';
$lang['Bid Details']	            											= 'Bid Details';
$lang['Portfolio']	            												= 'Portfolio';
$lang['Days']	            													= 'Days';
$lang['Hours']	            													= 'Hours';
$lang['Characters Left']	            										= 'Characters Left';
$lang['Submit']	            													= 'Submit';
$lang['Preview']	            												= 'Preview';
$lang['project_not_available']	            												= 'Project is not available';
$lang['Message:']='Message:';
$lang['Delivery Time']='Delivery Time';

?>
