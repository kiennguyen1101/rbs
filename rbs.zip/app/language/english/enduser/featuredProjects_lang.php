<?php
$lang['Featured Projects']	            = 'Featured Projects';
$lang['Urgent Projects']	            = 'Urgent Projects';
$lang['Projects']	            = 'Projects';
$lang['Open']	            = 'Open';
$lang['Frozen']	            = 'Frozen';
$lang['Closed']	            = 'Closed';
$lang['Job Type']	            = 'Job Type';
$lang['Budget']	            = 'Budget';
$lang['Status']	            = 'Status';
$lang['Bids']	            = 'Bids';
$lang['Avg Bid']	            = 'Avg Bid';
$lang['Start Date']	            = 'Start Date';
$lang['Type']	            = 'Type';
$lang['Date']	            = 'Date';
$lang['Type']	            = 'Type';
$lang['Description']	            = 'Description';
$lang['Results']	            = 'Results';
$lang['Refresh']	            = 'Refresh';
$lang['Customize Display']	            = 'Customize Display';
$lang['Rss Feed']	            = 'Rss Feed';
$lang['Post Project']	            = 'Post Project';
$lang['Project Name']	            = 'Project Name';
$lang['Customize Display:']='Customize Display:';

?>