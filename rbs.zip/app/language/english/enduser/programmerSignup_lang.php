<?php
$lang['new_programmer_signup']	            = 'New Provider Signup';
$lang['not_a_programmer']					= 'Not a Provider';
$lang['click_here']	        				= 'Click Here';
$lang['to_sign_buyer']	        			= 'to signup as a Buyer to place bids instead.';
$lang['provide_valid_mail']	       			= 'Please provide a valid e-mail address';
$lang['to_sign_buyer']	        			= 'to signup as a Buyer to start bidding on projects.';
$lang['view_privacy_policy']	       		= 'View our Privacy Policy';
$lang['email_address']	       				= 'E-mail Address';
$lang['programmer_email_validation']	    = 'Email';
$lang['confirmation_text']					= 'A confirmation e-mail has been sent to ';
$lang['follow_the_link']	    			= ',please follow the link inside to continue the signup process.';
$lang['programmer_email_check']	    			= 'This email is banned or already used';
$lang['programmer_username_check']	    		= 'This Username is banned or already used';
$lang['buyer_email_ban']				= 'This email id is banned or account activated for this email already';
$lang['Resend activation link']='Resend activation link';
$lang['Submit']='Submit';
$lang['?']='?';
$lang['not_registered']                 ='This email has not yet been registered';
?>
