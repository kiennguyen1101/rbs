<?php
$lang['Project Message Board']	            	= 'Project Message Board';
$lang['Job Message Board']	            	= 'Job Message Board';

$lang['Project']								= 'Project';
$lang['Post Message']							= 'Post Message';
$lang['To']										= 'To';
$lang['Everyone']								= 'Everyone';
$lang['From']								    = 'From';
$lang['Private Messsage']							= 'Private Messsage';
$lang['Note: Only private message to programmer']							= '[ Note: Please enter Provider id for private message with comma separate operator ]';
$lang['Select Project']							= 'Select Project';
$lang['Select Buyer']							= 'Select Buyer';
$lang['Select Provider']							= 'Select Provider';
$lang['message_validation']						= 'Message';
$lang['provider_validation']					= 'To';
$lang['project_validation']					= 'Project';

$lang['You must be logged in as a programmer to post messages on the Project Message Board']	= 'You must be logged in as a Provider to post messages on the Project Message Board';
$lang['Your Message Has Been Posted Successfully']						                        = 'Your message has been posted successfully';
$lang['You must be logged to post messages on the Project Message Board']					    = 'You must be logged to post messages on the Project Message Board';
$lang['You must be post project to invite programmers']					                        = 'You must be post project to invite Providers';
$lang['You must be logged to invite programmers']					                            = 'You must be logged to invite Providers';
$lang['There is no open project to Post Mail']	                                                = 'There is no open project to Post Mail';
$lang['You are currently logged in as']='You are currently logged in as';
$lang['Tip']='Tip: You can post programming code by placing it within [code] and [/code] tags.'; 
$lang['Submit']='Submit';
$lang['Preview']='Preview';
$lang['Hide']='Hide';
$lang['Show']='Show';
$lang['You are currently logged in as']='You are currently logged in as';
$lang['Job']					            = 'Job Name';

