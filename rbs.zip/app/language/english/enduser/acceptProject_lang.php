<?php
$lang['Project start']	            = 'Project start';
$lang['You have successfully accepted the project']	            = 'You have successfully accepted the project';
$lang['You cannot accept this project']	            = 'You cannot accept this project';
$lang['You have not released the Escrow Amount']	            = 'You have not released the Escrow Amount.';


?>