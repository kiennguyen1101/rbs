<?php
$lang['Search Results']	    = 'Search Results';
$lang['Open']	            = 'Open';
$lang['Frozen']	            = 'Frozen';
$lang['Closed']	            = 'Closed';
$lang['Professional Name']	= 'Provider Name';
$lang['Job Type']	        = 'Job Type';
$lang['Budget']	            = 'Budget';
$lang['Status']	            = 'Status';
$lang['Bids']	            = 'Bids';
$lang['Avg Bid']	        = 'Avg Bid';
$lang['Start Date']	        = 'Start Date';
$lang['Type']	            = 'Type';
$lang['Date']	            = 'Date';
$lang['Type']	            = 'Type';
$lang['Description']	    = 'Description';
$lang['Results']	        = 'Results';
$lang['Refresh']	        = 'Refresh';
$lang['Customize Display']	= 'Customize Display';
?>
