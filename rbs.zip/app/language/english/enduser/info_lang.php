<?php
$lang['Go Back']	            = 'Go Back';