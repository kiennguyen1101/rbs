<?php 
$lang['view support']	            = 'View	support';
$lang['edit ticket']	            = 'Edit	Ticket';
$lang['edit']						= 'Edit';
$lang['view_tickets']	            = 'View Tickets';
$lang['page_url']	                = 'Link to page';
$lang['priority']					= 'Priority';
$lang['category']					= 'Category';
$lang['subject']            		= 'subject';
$lang['status']						= 'Status';
$lang['description']				= 'Description';
$lang['action']						= 'Action';
$lang['Submit']						='Submit';
$lang['urgent']						='Urgent';
$lang['high']						='High';
$lang['normal']						='Normal';
$lang['low']						='Low';
$lang['very low']						='Very Low';
$lang['general']						='General';
$lang['billing']						='Billing';
$lang['suspended accounts']						='Suspended Accounts';
$lang['problems']						='Problems';
$lang['abuse']						='Abuse';
$lang['call id']					='Call Id';
$lang['open']					='Open';
$lang['close']					='Close';

$lang['the RBS support desk']					='The RBS Support Desk';


?>