<?php
$lang['total_validation']	 						 = 'Amount';
$lang['Paypal']	 						 = 'Paypal';
$lang['Dont have rights to access this page']	     = 'Dont have rights to access this page';
$lang['buyer_id_validation']	 					 = 'Buyer';
$lang['project_id_validation']	 					 = 'Project';
$lang['amount_validation']	 						 = 'Amount';
$lang['programmer_id_validation']	 				 = 'Provider';
$lang['Select Programmer']	 				         = 'Select Provider';
$lang['Select Buyer']	 				             = 'Select Buyer';
$lang['Select Project']	 				             = 'Select Project';
$lang['Transfer Amount']	 				         = 'Amount $';
$lang['Send Money']	 				                 = 'Send Money';
$lang['Please Choose the Project']	 				 = 'Please Choose the Project Id';
$lang['Please Choose the Programmer']	 			 = 'Please Choose the Provider';
$lang['Please enter the Amount']	 				 = 'Please enter the Amount';
$lang['Your Transaction successfully Completed']	 = 'Your Transaction successfully Completed';
$lang['Transfer Amount should not be empty']	 	 = 'Transfer Amount should not be empty or Zero';
$lang['You are not having Sufficient Balance to Transfer']	 	 = 'You are not having Sufficient Balance to Transfer';
$lang['Tansfer Amount Through']                      =  'Tansfer Amount Through';
$lang['Enter the Amount']                            =  'Enter the Amount';
$lang['Invalid Input Value']                         =  'Invalid Input Value';
$lang['Transfer Funds']='Transfer Funds';
$lang['User name :']='User name :';
$lang['Account Balance:']='Account Balance:';
$lang['SI.No']='SI.No';
$lang['From']='From';
$lang['Amount']='Amount';
$lang['To']='To';
$lang['Date']='Date';
$lang['Status']='Status';
$lang['select']='Select your prefered deposit method below and then click the deposit button.';
$lang['Transfer']='Transfer';
$lang['My Transfer Transactions']='My Transfer Transactions';

	 