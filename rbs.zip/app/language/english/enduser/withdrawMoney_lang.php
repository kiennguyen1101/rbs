<?php
$lang['total_validation']	 						 = 'Amount';
$lang['paypal_email']	 						     = 'Email';
$lang['Dont have rights to access this page']	     = 'Dont have rights to access this page';
$lang['Paypal']										 = 'Paypal';
$lang['paymentMethod_validation']	 				 = 'Payment Method';
$lang['Amount Deposited Through']					 = 'Amount Deposited Through';
$lang['withdraw_funds']	 							 = 'Withdraw Funds';
$lang['Withdraw']	 							 	 = 'Withdraw';
$lang['user_name'] 									 = 'User name:';
$lang['Payment Methods'] 							 = 'Payment Methods';
$lang['Cost'] 										 = 'Cost';
$lang['Approval'] 									 = 'Approval';
$lang['note'] 										 = '(Select your prefered withdraw method below and then click the deposit button.)';
$lang['email']	 						             = 'Email';	
$lang['Withdraw Amount From']                        = 'Withdraw Amount From';
$lang['Withdraw success']                            = 'Your amount can be withdraw within 48 Hours';
$lang['Withdraw Funds']                              = 'Withdraw Funds';
$lang['check balance']                               = 'check balance';
$lang['your not having sufficient balance']          = 'You are not having sufficient balance'; 
$lang['minimun withdraw amount is $ 5.00']           = 'Minimun withdraw amount is $ 5.00'; 
$lang['minimun maintainance amount is $ 5.00']       = 'Minimun maintainance amount is $ 5.00';  
$lang['Your current Balance amount :']               = 'Your current Balance amount : $ ';
$lang['Your available Balance amount for withdraw :']               = 'Your available Balance amount for withdraw : $ ';
$lang['Minimum withdraw amount :']                   = 'Minimum withdraw amount : $ ';
$lang['Please enter your paypal address']            = 'Please enter your paypal address';
$lang['Account Balance:']='Account Balance:';
$lang['Withdraw Amount:']='Withdraw Amount:';
$lang['Payment methods']='Payment methods';
$lang['Payment Method']='Payment Method';
$lang['Cost']='Cost';
$lang['Approval']='Approval';
$lang['Description']='Description';
$lang['No Cost']='No Cost';
$lang['Instant*']='Instant*';
$lang['wire']='Wire funds from your bank anywhere in the world. A preferred method for payments above $200. Secure and simple; No verification necessary.';
$lang['Deposit']='Deposit';
$lang['My Deposit Transactions']='My Deposit Transactions';
$lang['SI.No']='SI.No';
$lang['From']='From';
$lang['Amount']='Amount';
$lang['Date']='Date';
$lang['Status']='Status';
$lang['My Withdraw Transactions']='My Withdraw Transactions';
// For moneybookers
$lang['MoneyBooker']='MoneyBookers';
$lang['Please enter your moneybooker address']            = 'Please enter your MoneyBookers address';
$lang['moneybookers_approval_time'] = 'Instant';
$lang['moneybookers_cost'] = '% of Total Withdraw';

//For Paypal
$lang['paypal_cost'] = ' % of Total Withdraw';
$lang['paypal_approval_time'] = 'Instant';

?>
