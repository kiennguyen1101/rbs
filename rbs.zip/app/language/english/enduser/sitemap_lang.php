<?php
$lang['SITE MAP']='SITE MAP';
$lang['General']='General';
$lang['RSS Feeds']='RSS Feeds';
$lang['FAQs']='FAQs';
$lang['Reports']='Reports';
$lang['Contacts']='Contacts';
$lang['Forgot Password?']='Forgot Password?';
$lang['Provide Services']='Provide Services';
$lang['Sign Up']='Sign Up';
$lang['Find Projects']='Find Projects';
$lang['Latest Projects']='Latest Projects';
$lang['Featured Projects']='Featured Projects';
$lang['High Budget Projects']='High Budget Projects';
$lang['Urgent Projects']='Urgent Projects';
$lang['Get Services']='Get Services';
$lang['Post Your Project']='Post Your Project';
$lang['Sign Up']='Sign Up';
$lang['Top Programmers']='Top Providers';
$lang['Latest Projects']='Latest Projects';
$lang['Services Categories']='Services Categories';

