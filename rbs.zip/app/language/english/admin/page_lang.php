<?php 
$lang['add_Page']	            	= 'Add Page';
$lang['edit_Page']	            	= 'Edit	Page';
$lang['edit']						= 'Edit';
$lang['add_page']	            	= 'Add Page';
$lang['view_page']	                = 'View Page';
$lang['page_url']	                = 'Link to page';
$lang['page_title']					= 'Title';
$lang['page_content']				= 'Page Content';
$lang['added_success']              = 'Added Successfully';
$lang['page_unique']				= 'The Page Name should be unique';
$lang['page_name']					= 'Page Name';
$lang['url_unique']				    = 'The UrL Name should be unique';
$lang['page_url_check']             = 'Only alphabets and undersorce are allowed';
$lang['Submit']='Submit';
$lang['No Pages Found']='No Pages Found';

