<script type="text/javascript" src="<?php echo base_url() ?>app/js/livepipe.js"></script>
<script type="text/javascript" src="<?php echo base_url() ?>app/js/tabs.js"></script>
<div class="infoTabs">
 <ul id="tabs_example_one" class="subsection_tabs ">  
     <li class="tab">
	 <span>
	 <a href="#EyeForWeb">EyeForWeb</a>
	 </span>
	 </li>  
     <li class="tab"><span><a href="#Zdesign">Zdesign</a></span></li>
	 <li class="tab"><span><a href="#Guru">Guru</a></span></li>
	 <li class="tab"><span><a href="#website">website</a></span></li>
	 <li class="tab"><span><a href="#component">component</a></span></li>  
 </ul>
 <div class="infoTabContent">
 <div id="EyeForWeb"><p>This is the simplest example of a set of tabs.</p></div>  
 <div id="Zdesign"><p>component e with CSS, not the Control.Tabs script.</p></div>
 <div id="Guru"><p>fghfghfghfdhfgh.</p></div>
 <div id="website"><p>fghfghfgdhfgh.</p></div>
 <div id="component"><p>fghfghdh.</p></div>
 </div>
 </div>
 <script type="text/javascript">
	  new Control.Tabs('tabs_example_one');		
 </script>	  

