<!--SEARCH-->
<div class="clsMainSearch">
  <div class="navmenutabs">
    <ul>
      <li id="work"><a href="javascript:;" onclick="checkFind('work')"><span><?php echo $this->lang->line('Find Work');?></span></a></li>
      <li id="prof"><a href="javascript:;" onclick="checkFind('proff')"><span><?php echo $this->lang->line('Find Profesional');?></span></a></li>
    </ul>
  </div>
  <div class="boxholder">
    <div class="block">
      <div class="search_t">
        <div class="search_r">
          <div class="search_b">
            <div class="search_l">
              <div class="search_tl">
                <div class="search_tr">
                  <div class="search_bl">
                    <div class="search_br">
                      <div class="cls100_p">
                        <div class="clsSearchBox clsSitelinks" id="innerContent">
                         
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--END OF SEARCH-->