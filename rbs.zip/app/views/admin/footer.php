</div> <!--END OF CONTENT BLOCK-->
</div>
  <div id="footer">
	<p><?php echo $this->lang->line('&copy; Copyright Cogzidel 2010');?> </p>
  </div>

</div>
</body>
</html>