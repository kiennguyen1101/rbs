<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Reverse Bidding System
 * Debugg  Related Helper
 */	
	function pr($str='')
	{
		echo '<pre>';
		print_r($str);
		echo '<pre>';
	}

/* End of file text_helper.php */
/* Location: ./app/helpers/debug_helper.php */